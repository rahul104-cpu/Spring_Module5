package com.intellipaat.usermanagement;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "users")
public class User {
   @Id
   @GeneratedValue
   private int id;
   @Column(name = "firstname")
   private String fname;
   @Column(name = "lastname")
   private String lname;
   private int age;
   public int getId() {
       return id;
   }
   public void setId(int id) {
       this.id = id;
   }
   public String getFname() {
       return fname;
   }
   public void setFname(String fname) {
       this.fname = fname;
   }
   public String getLname() {
       return lname;
   }
   public void setLname(String lname) {
       this.lname = lname;
   }
   public void setAge(int age) {
       this.age = age;
   }
   public int getAge() {
       return age;
   }
   @Override
   public String toString() {
       return "User{" +
               "id=" + id +
               ", fname='" + fname + '\'' +
               ", lname='" + lname + '\'' +
               ", age=" + age +
               '}';
   }
}
